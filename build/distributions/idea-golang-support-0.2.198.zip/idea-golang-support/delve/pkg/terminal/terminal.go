package terminal

//lint:file-ignore ST1005 errors here can be capitalized

import (
	"errors"
	"fmt"
	"io"
	"net/rpc"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/derekparker/trie/v3"
	"github.com/go-delve/liner"

	"github.com/go-delve/delve/pkg/config"
	"github.com/go-delve/delve/pkg/goversion"
	"github.com/go-delve/delve/pkg/locspec"
	"github.com/go-delve/delve/pkg/proc"
	"github.com/go-delve/delve/pkg/terminal/colorize"
	"github.com/go-delve/delve/pkg/terminal/starbind"
	"github.com/go-delve/delve/service"
	"github.com/go-delve/delve/service/api"
)

const (
	historyFile                 string = ".dbg_history"
	terminalHighlightEscapeCode string = "\033[%2dm"
	terminalResetEscapeCode     string = "\033[0m"
	defaultPrompt                      = "(dlv) "
)

const (
	ansiBlack     = 30
	ansiRed       = 31
	ansiGreen     = 32
	ansiYellow    = 33
	ansiBlue      = 34
	ansiMagenta   = 35
	ansiCyan      = 36
	ansiWhite     = 37
	ansiBrBlack   = 90
	ansiBrRed     = 91
	ansiBrGreen   = 92
	ansiBrYellow  = 93
	ansiBrBlue    = 94
	ansiBrMagenta = 95
	ansiBrCyan    = 96
	ansiBrWhite   = 97
)

// Term represents the terminal running dlv.
type Term struct {
	client   service.Client
	conf     *config.Config
	line     *liner.State
	cmds     *Commands
	stdout   *transcriptWriter
	InitFile string
	displays []displayEntry
	oldPid   int

	stackTraceColors api.StackTraceColors

	historyFile *os.File

	starlarkEnv *starbind.Env

	substitutePathRulesCache [][2]string

	// isAttachCmd is true if this terminal was stated by 'dlv attach...'
	isAttachCmd bool

	// quitContinue is set to true by exitCommand to signal that the process
	// should be resumed before quitting.
	quitContinue bool

	// detachNoKill is set to true by exitCommand when passed -d to signal that
	// the target process should be left running, without prompting.
	detachNoKill bool

	longCommandMu         sync.Mutex
	longCommandCancelFlag bool

	quittingMutex sync.Mutex
	quitting      bool

	traceNonInteractive bool
	TraceVerbosity      int // Verbosity level for trace output (0-4)

	downloadsMu         sync.Mutex
	downloadsInProgress bool

	goVersionCache *goversion.GoVersion
	// customCommandsInvalidated is set when a runCmd is executed during custom command execution
	customCommandsInvalidated []bool
}

type displayEntry struct {
	expr   string
	fmtstr string
}

// New returns a new Term.
func New(client service.Client, conf *config.Config, isAttachCmd bool) *Term {
	cmds := DebugCommands(client)
	if conf != nil && conf.Aliases != nil {
		cmds.Merge(conf.Aliases)
	}

	if conf == nil {
		conf = &config.Config{}
	}

	t := &Term{
		client: client,
		conf:   conf,
		line:   liner.NewLiner(),
		cmds:   cmds,
		stdout: &transcriptWriter{pw: &pagingWriter{w: os.Stdout}},

		isAttachCmd: isAttachCmd,
	}
	t.line.SetCtrlZStop(true)

	if strings.ToLower(os.Getenv("TERM")) != "dumb" {
		t.stdout.pw = &pagingWriter{w: getColorableWriter()}
		t.stdout.colorEscapes = make(map[colorize.Style]string)
		t.stdout.colorEscapes[colorize.NormalStyle] = terminalResetEscapeCode
	}

	t.updateConfig()

	if client != nil {
		lcfg := t.loadConfig()
		client.SetReturnValuesLoadConfig(&lcfg)
		if state, err := client.GetState(); err == nil {
			t.oldPid = state.Pid
		}
		firstEventBinaryInfoDownload := true
		client.SetEventsFn(func(event *api.Event) {
			switch event.Kind {
			case api.EventResumed:
				firstEventBinaryInfoDownload = true
			case api.EventBinaryInfoDownload:
				t.downloadsMu.Lock()
				t.downloadsInProgress = true
				t.downloadsMu.Unlock()
				if !firstEventBinaryInfoDownload {
					fmt.Fprintf(t.stdout, "\r")
					if strings.ToLower(os.Getenv("TERM")) != "dumb" {
						fmt.Fprintf(t.stdout, "\x1b[J") // clear to the end of the line
					}
				}
				fmt.Fprintf(t.stdout, "Downloading debug info for %s: %s (press ^C to cancel)", event.BinaryInfoDownloadEventDetails.ImagePath, event.BinaryInfoDownloadEventDetails.Progress)
				firstEventBinaryInfoDownload = false
			case api.EventStopped, api.EventDownloadLibraryInfoDone:
				t.downloadsMu.Lock()
				t.downloadsInProgress = false
				t.downloadsMu.Unlock()
				if !firstEventBinaryInfoDownload {
					fmt.Fprintf(t.stdout, "\n")
				}
				firstEventBinaryInfoDownload = true
			case api.EventBreakpointMaterialized:
				bp := event.BreakpointMaterializedEventDetails.Breakpoint
				file := t.formatPath(bp.File)

				// Append the function name.
				var extra string
				if bp.FunctionName != "" {
					extra = " (" + bp.FunctionName + ")"
				}

				fmt.Fprintf(t.stdout, "Breakpoint %d materialized at %s:%d%s\n", bp.ID, file, bp.Line, extra)
			case api.EventProcessSpawned:
				fmt.Fprintf(t.stdout, "Spawned new process '%s' (%d)\n", event.Cmdline, event.ProcessSpawnedEventDetails.PID)
			}
		})
	}

	t.starlarkEnv = starbind.New(starlarkContext{t}, t.stdout)
	return t
}

func (t *Term) updateConfig() {
	// These are always called together.
	t.updateColorScheme()
	t.updateTab()
}

func (t *Term) updateColorScheme() {
	if t.stdout.colorEscapes == nil {
		return
	}

	conf := t.conf
	wd := func(s string, defaultCode int) string {
		if s == "" {
			return fmt.Sprintf(terminalHighlightEscapeCode, defaultCode)
		}
		return s
	}
	t.stdout.colorEscapes[colorize.KeywordStyle] = conf.SourceListKeywordColor
	t.stdout.colorEscapes[colorize.StringStyle] = wd(conf.SourceListStringColor, ansiGreen)
	t.stdout.colorEscapes[colorize.NumberStyle] = conf.SourceListNumberColor
	t.stdout.colorEscapes[colorize.CommentStyle] = wd(conf.SourceListCommentColor, ansiBrMagenta)
	t.stdout.colorEscapes[colorize.ArrowStyle] = wd(conf.SourceListArrowColor, ansiYellow)
	t.stdout.colorEscapes[colorize.TabStyle] = wd(conf.SourceListTabColor, ansiBrBlack)
	switch x := conf.SourceListLineColor.(type) {
	case string:
		t.stdout.colorEscapes[colorize.LineNoStyle] = x
	case int:
		if (x > ansiWhite && x < ansiBrBlack) || x < ansiBlack || x > ansiBrWhite {
			x = ansiBlue
		}
		t.stdout.colorEscapes[colorize.LineNoStyle] = fmt.Sprintf(terminalHighlightEscapeCode, x)
	case nil:
		t.stdout.colorEscapes[colorize.LineNoStyle] = fmt.Sprintf(terminalHighlightEscapeCode, ansiBlue)
	}

	wd2 := func(s, defaultStr string) string {
		if s == "" {
			return defaultStr
		}
		return s
	}

	t.stackTraceColors.FunctionColor = wd2(conf.StackTraceFunctionColor, "\033[1m")
	t.stackTraceColors.BasenameColor = wd2(conf.StackTraceBasenameColor, "\033[1m")
	t.stackTraceColors.NormalColor = terminalResetEscapeCode
}

func (t *Term) updateTab() {
	t.stdout.altTabString = t.conf.Tab
}

func (t *Term) SetTraceNonInteractive() {
	t.traceNonInteractive = true
}

func (t *Term) IsTraceNonInteractive() bool {
	return t.traceNonInteractive
}

// Close returns the terminal to its previous mode.
func (t *Term) Close() {
	t.line.Close()
	if err := t.stdout.CloseTranscript(); err != nil {
		fmt.Fprintf(os.Stderr, "error closing transcript file: %v\n", err)
	}
}

func (t *Term) sigintGuard(ch <-chan os.Signal, multiClient bool) {
	for range ch {
		t.downloadsMu.Lock()
		downloadsInProgress := t.downloadsInProgress
		t.downloadsMu.Unlock()
		if downloadsInProgress {
			t.client.CancelDownloads()
			continue
		}

		t.longCommandCancel()
		t.starlarkEnv.Cancel()
		state, err := t.client.GetStateNonBlocking()
		if err == nil && state.Recording {
			fmt.Fprintf(t.stdout, "received SIGINT, stopping recording (will not forward signal)\n")
			err := t.client.StopRecording()
			if err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			continue
		}
		if err == nil && state.CoreDumping {
			fmt.Fprintf(t.stdout, "received SIGINT, stopping dump\n")
			err := t.client.CoreDumpCancel()
			if err != nil {
				fmt.Fprintf(os.Stderr, "%v\n", err)
			}
			continue
		}
		if multiClient {
			answer, err := t.line.Prompt("Would you like to [p]ause the target (returning to Delve's prompt) or [q]uit this client (leaving the target running) [p/q]? ")
			if err != nil {
				fmt.Fprintf(os.Stderr, "%v", err)
				continue
			}
			answer = strings.TrimSpace(answer)
			switch answer {
			case "p":
				_, err := t.client.Halt()
				if err != nil {
					fmt.Fprintf(os.Stderr, "%v", err)
				}
			case "q":
				t.quittingMutex.Lock()
				t.quitting = true
				t.quittingMutex.Unlock()
				err := t.client.Disconnect(false)
				if err != nil {
					fmt.Fprintf(os.Stderr, "%v", err)
				} else {
					t.Close()
				}
			default:
				fmt.Fprintln(t.stdout, "only p or q allowed")
			}
		} else {
			fmt.Fprintf(t.stdout, "received SIGINT, stopping process (will not forward signal)\n")
			_, err := t.client.Halt()
			if err != nil {
				fmt.Fprintf(t.stdout, "%v", err)
			}
		}
	}
}

// Run begins running dlv in the terminal.
func (t *Term) Run() (int, error) {
	defer t.Close()

	multiClient := t.client.IsMulticlient()

	// Send the debugger a halt command on SIGINT
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGINT)
	go t.sigintGuard(ch, multiClient)

	cmds := trie.New[any]()
	for _, cmd := range t.cmds.cmds {
		for _, alias := range cmd.aliases {
			cmds.Add(alias, nil)
		}
	}

	var fns *trie.Trie[any]
	var locs *trie.Trie[any]

	t.line.SetCompleter(func(line string) (c []string) {
		cmd := t.cmds.Find(strings.Split(line, " ")[0], noPrefix)
		switch cmd.aliases[0] {
		case "break", "trace", "continue":
			if spc := strings.LastIndex(line, " "); spc > 0 {
				prefix := line[:spc] + " "
				if fns == nil {
					fns = trie.New[any]()
					funcs, _ := t.client.ListFunctions("", 0)
					for _, fn := range funcs {
						fns.Add(fn, nil)
					}
				}
				funcs := fns.FuzzySearch(line[spc+1:])
				for _, f := range funcs {
					c = append(c, prefix+f)
				}
			}
		case "nullcmd", "nocmd":
			commands := cmds.FuzzySearch(strings.ToLower(line))
			c = append(c, commands...)
		case "print", "whatis":
			if locs == nil {
				localVars, err := t.client.ListLocalVariables(
					api.EvalScope{GoroutineID: -1, Frame: t.cmds.frame, DeferredCall: 0},
					api.LoadConfig{},
				)
				if err != nil {
					fmt.Fprintf(os.Stderr, "Unable to get local variables: %s\n", err)
					break
				}

				locs = trie.New[any]()
				for _, loc := range localVars {
					locs.Add(loc.Name, nil)
				}
			}

			if spc := strings.LastIndex(line, " "); spc > 0 {
				prefix := line[:spc] + " "
				locals := locs.FuzzySearch(line[spc+1:])
				for _, l := range locals {
					c = append(c, prefix+l)
				}
			}
		}
		return
	})

	fullHistoryFile, err := config.GetConfigFilePath(historyFile)
	if err != nil {
		fmt.Printf("Unable to load history file: %v.", err)
	}

	t.historyFile, err = os.OpenFile(fullHistoryFile, os.O_RDWR|os.O_CREATE, 0600)
	if err != nil {
		fmt.Printf("Unable to open history file: %v. History will not be saved for this session.", err)
	}
	if _, err := t.line.ReadHistory(t.historyFile); err != nil {
		fmt.Printf("Unable to read history file %s: %v\n", fullHistoryFile, err)
	}

	fmt.Println("Type 'help' for list of commands.")

	if t.InitFile != "" {
		err := t.cmds.executeFile(t, t.InitFile)
		if err != nil {
			if _, ok := err.(ExitRequestError); ok {
				return t.handleExit()
			}
			fmt.Fprintf(os.Stderr, "Error executing init file: %s\n", err)
		}
	}

	var lastCmd string

	// Ensure that the target process is neither running nor recording by
	// making a blocking call.
	_, _ = t.client.GetState()

	if t.isAttachCmd {
		t.client.DownloadLibraryDebugInfo(-1)
	}

	for {
		locs = nil

		prompt := defaultPrompt
		if t.conf != nil && t.conf.Prompt != "" {
			prompt = t.expandPrompt(t.conf.Prompt)
		}

		cmdstr, err := t.promptForInput(prompt)
		if err != nil {
			if err == io.EOF {
				fmt.Fprintln(t.stdout, "exit")
				return t.handleExit()
			}
			return 1, errors.New("Prompt for input failed.\n")
		}
		t.stdout.Echo(prompt + cmdstr + "\n")

		if strings.TrimSpace(cmdstr) == "" {
			cmdstr = lastCmd
		}

		lastCmd = cmdstr

		if err := t.cmds.Call(cmdstr, t); err != nil {
			if _, ok := err.(ExitRequestError); ok {
				return t.handleExit()
			}
			// The type information gets lost in serialization / de-serialization,
			// so we do a string compare on the error message to see if the process
			// has exited, or if the command actually failed.
			if strings.Contains(err.Error(), "exited") {
				fmt.Fprintln(os.Stderr, err.Error())
			} else {
				t.quittingMutex.Lock()
				quitting := t.quitting
				t.quittingMutex.Unlock()
				if quitting {
					return t.handleExit()
				}
				fmt.Fprintf(os.Stderr, "Command failed: %s\n", err)
			}
		}

		t.stdout.Flush()
		t.stdout.pw.Reset()
	}
}

// Substitutes directory to source file.
//
// Ensures that only directory is substituted, for example:
// substitute from `/dir/subdir`, substitute to `/new`
// for file path `/dir/subdir/file` will return file path `/new/file`.
// for file path `/dir/subdir-2/file` substitution will not be applied.
//
// If more than one substitution rule is defined, the rules are applied
// in the order they are defined, first rule that matches is used for
// substitution.
func (t *Term) substitutePath(path string) string {
	if t.conf == nil {
		return path
	}
	return locspec.SubstitutePath(path, t.substitutePathRules())
}

func (t *Term) substitutePathRules() [][2]string {
	if t.substitutePathRulesCache != nil {
		return t.substitutePathRulesCache
	}
	if t.conf == nil || t.conf.SubstitutePath == nil {
		return nil
	}
	spr := make([][2]string, 0, len(t.conf.SubstitutePath))
	for _, r := range t.conf.SubstitutePath {
		spr = append(spr, [2]string{r.From, r.To})
	}
	t.substitutePathRulesCache = spr
	return spr
}

// formatPath applies path substitution rules and shortens the resulting
// path by replacing the current directory with './'
func (t *Term) formatPath(path string) string {
	path = t.substitutePath(path)
	workingDir, _ := os.Getwd()
	return strings.Replace(path, workingDir, ".", 1)
}

func (t *Term) promptForInput(prompt string) (string, error) {
	if t.stdout.colorEscapes != nil && t.conf.PromptColor != "" {
		fmt.Fprint(os.Stdout, t.conf.PromptColor)
		defer fmt.Fprint(os.Stdout, terminalResetEscapeCode)
	}
	l, err := t.line.Prompt(prompt)
	if err != nil {
		return "", err
	}

	l = strings.TrimSuffix(l, "\n")
	if l != "" {
		t.line.AppendHistory(l)
	}

	return l, nil
}

var yesno = func(line *liner.State, question, defaultAnswer string) (bool, error) {
	for {
		answer, err := line.Prompt(question)
		if err != nil {
			return false, err
		}
		answer = strings.ToLower(strings.TrimSpace(answer))
		if answer == "" {
			answer = defaultAnswer
		}
		switch answer {
		case "n", "no":
			return false, nil
		case "y", "yes":
			return true, nil
		}
	}
}

func (t *Term) handleExit() (int, error) {
	if t.historyFile != nil {
		if _, err := t.line.WriteHistory(t.historyFile); err != nil {
			fmt.Println("readline history error:", err)
		}
		if err := t.historyFile.Close(); err != nil {
			fmt.Printf("error closing history file: %s\n", err)
		}
	}

	t.quittingMutex.Lock()
	quitting := t.quitting
	t.quittingMutex.Unlock()
	if quitting {
		return 0, nil
	}

	s, err := t.client.GetState()
	if err != nil {
		if isErrProcessExited(err) {
			if t.client.IsMulticlient() {
				answer, err := yesno(t.line, "Remote process has exited. Would you like to kill the headless instance? [Y/n] ", "yes")
				if err != nil {
					return 2, io.EOF
				}
				if answer {
					if err := t.client.Detach(true); err != nil {
						return 1, err
					}
				}
				return 0, err
			}
			return 0, nil
		}
		return 1, err
	}
	if !s.Exited {
		if t.quitContinue {
			err := t.client.Disconnect(true)
			if err != nil {
				return 2, err
			}
			return 0, nil
		}

		doDetach := true
		if t.client.IsMulticlient() {
			answer, err := yesno(t.line, "Would you like to kill the headless instance? [Y/n] ", "yes")
			if err != nil {
				return 2, io.EOF
			}
			doDetach = answer
		}

		if doDetach {
			kill := true
			if t.client.AttachedToExistingProcess() && !t.detachNoKill {
				answer, err := yesno(t.line, "Would you like to kill the process? [Y/n] ", "yes")
				if err != nil {
					return 2, io.EOF
				}
				kill = answer
			}
			if t.detachNoKill {
				kill = false
			}
			if err := t.client.Detach(kill); err != nil {
				return 1, err
			}
		}
	}
	return 0, nil
}

// loadConfig returns an api.LoadConfig with the parameters specified in
// the configuration file.
func (t *Term) loadConfig() api.LoadConfig {
	full := proc.LoadFullValue()
	r := *api.LoadConfigFromProc(&full)

	if t.conf != nil && t.conf.MaxStringLen != nil {
		r.MaxStringLen = *t.conf.MaxStringLen
	}
	if t.conf != nil && t.conf.MaxArrayValues != nil {
		r.MaxArrayValues = *t.conf.MaxArrayValues
	}
	if t.conf != nil && t.conf.MaxVariableRecurse != nil {
		r.MaxVariableRecurse = *t.conf.MaxVariableRecurse
	}

	return r
}

func (t *Term) removeDisplay(n int) error {
	if n < 0 || n >= len(t.displays) {
		return fmt.Errorf("%d is out of range", n)
	}
	t.displays[n] = displayEntry{"", ""}
	for i := len(t.displays) - 1; i >= 0; i-- {
		if t.displays[i].expr != "" {
			t.displays = t.displays[:i+1]
			return nil
		}
	}
	t.displays = t.displays[:0]
	return nil
}

func (t *Term) addDisplay(expr, fmtstr string) {
	t.displays = append(t.displays, displayEntry{expr: expr, fmtstr: fmtstr})
}

// rawStringFlag returns the PrettyRawString flag if the config enables it.
func (t *Term) rawStringFlag() api.PrettyFlags {
	if t.conf.ShowRawStrings {
		return api.PrettyRawString
	}
	return 0
}

func (t *Term) printDisplay(i int) {
	expr, fmtstr := t.displays[i].expr, t.displays[i].fmtstr
	val, err := t.client.EvalVariable(api.EvalScope{GoroutineID: -1}, expr, ShortLoadConfig)
	if err != nil {
		if isErrProcessExited(err) {
			return
		}
		fmt.Fprintf(t.stdout, "%d: %s = error %v\n", i, expr, err)
		return
	}
	fmt.Fprintf(t.stdout, "%d: %s = %s\n", i, val.Name, val.StringWithOptions("", fmtstr, t.rawStringFlag()))
}

func (t *Term) printDisplays() {
	for i := range t.displays {
		if t.displays[i].expr != "" {
			t.printDisplay(i)
		}
	}
}

func (t *Term) onStop() {
	t.printDisplays()
	t.cmds.executeBreakpointCustomCommands(t)
}

func (t *Term) longCommandCancel() {
	t.longCommandMu.Lock()
	defer t.longCommandMu.Unlock()
	t.longCommandCancelFlag = true
}

func (t *Term) longCommandStart() {
	t.longCommandMu.Lock()
	defer t.longCommandMu.Unlock()
	t.longCommandCancelFlag = false
}

func (t *Term) longCommandCanceled() bool {
	t.longCommandMu.Lock()
	defer t.longCommandMu.Unlock()
	return t.longCommandCancelFlag
}

// RedirectTo redirects the output of this terminal to the specified writer.
func (t *Term) RedirectTo(w io.Writer) {
	t.stdout.pw.w = w
}

func (t *Term) goVersion() *goversion.GoVersion {
	if t.goVersionCache != nil {
		return t.goVersionCache
	}
	vers := t.client.GetVersion()
	v := goversion.ParseProducer(vers.TargetGoVersion)
	t.goVersionCache = &v
	return t.goVersionCache
}

func (t *Term) expandPrompt(prompt string) string {
	const escape = '$'
	var malformedEscape = []byte("<malformed escape>")

	var hasState bool
	var pid, tid int
	var goid int64

	getState := func() {
		if hasState {
			return
		}
		hasState = true
		state, err := t.client.GetState()
		if err != nil {
			return
		}
		pid = state.Pid
		if state.SelectedGoroutine != nil {
			goid = state.SelectedGoroutine.ID
		}
		if state.CurrentThread != nil {
			tid = state.CurrentThread.ID
		}
	}

	var buf []byte
	s := 0
	flush := func(e int) {
		if s >= len(prompt) {
			return
		}
		if buf == nil {
			buf = make([]byte, 0, len(prompt))
		}
		buf = append(buf, []byte(prompt[s:e])...)
		s = e
	}
	for i := 0; i < len(prompt); i++ {
		if prompt[i] == escape {
			flush(i)
			i++
			s = i + 1
			if i >= len(prompt) {
				buf = append(buf, malformedEscape...)
				break
			}
			switch prompt[i] {
			case '$':
				buf = append(buf, '$')
			case 'd':
				formatStr := time.RFC3339
				if i+1 < len(prompt) && prompt[i] == '{' {
					fs := i + 1
					for ; i < len(prompt); i++ {
						if prompt[i] == '}' {
							break
						}
					}
					formatStr = prompt[fs:i]
					s = i + 1
				}
				buf = append(buf, []byte(time.Now().Format(formatStr))...)
			case 'f':
				buf = strconv.AppendInt(buf, int64(t.cmds.frame), 10)
			case 'g':
				getState()
				buf = strconv.AppendInt(buf, goid, 10)
			case 't':
				getState()
				buf = strconv.AppendInt(buf, int64(tid), 10)
			case 'p':
				getState()
				buf = strconv.AppendInt(buf, int64(pid), 10)
			default:
				buf = append(buf, malformedEscape...)
			}
		}
	}
	if buf == nil {
		return prompt
	}
	flush(len(prompt))
	return string(buf)
}

// isErrProcessExited returns true if `err` is an RPC error equivalent of proc.ErrProcessExited
func isErrProcessExited(err error) bool {
	rpcError, ok := err.(rpc.ServerError)
	return ok && strings.Contains(rpcError.Error(), "has exited with status")
}
